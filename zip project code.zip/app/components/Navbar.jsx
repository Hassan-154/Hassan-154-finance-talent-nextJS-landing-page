"use client"
import React, { useState } from 'react';
import { RiMenuLine, RiCloseLine } from 'react-icons/ri';
import navData from '../constant/navbar.json';
import Button from './Button';

const NavBar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="bg-white border-b border-[#E2E8F0] sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-3 sm:px-4 lg:px-0">
        <div className="flex items-center justify-between h-16 lg:justify-start">
          {/* Logo */}
          <div className="flex-shrink-0">
            <div className="text-xl font-bold text-black"><a href='#'>LOGO</a></div>
          </div>

          {/* Navigation Menu - Shared HTML for both desktop and mobile */}
          <div className={`${isOpen ? 'max-h-screen opacity-100 translate-y-0' : 'max-h-0 opacity-0 -translate-y-4'} lg:max-h-none lg:opacity-100 lg:translate-y-0 lg:flex lg:flex-1 lg:justify-center absolute lg:relative top-16 lg:top-0 left-0 lg:left-auto w-full lg:w-auto bg-white lg:bg-transparent z-50 lg:z-auto overflow-hidden lg:overflow-visible transition-all duration-300 ease-in-out`}>
            <div className="flex flex-col lg:flex-row lg:items-center px-2 py-2 lg:p-0 space-y-1 lg:space-y-0 lg:space-x-10">
              {navData.menuItems.map((item, index) => (
                <a
                  key={index}
                  href={item.link}
                  className="text-black hover:text-gray-700 block lg:inline px-3 py-2 lg:p-0 text-base lg:text-[15px] lg:font-thin"
                >
                  {item.name}
                </a>
              ))}
            </div>
          </div>

          {/* Buttons - Shared HTML for both desktop and mobile */}
          <div className={`${isOpen ? 'max-h-screen opacity-100 translate-y-0 border-b border-[#E2E8F0] lg:border-none' : 'max-h-0 opacity-0 -translate-y-4'} lg:max-h-none lg:opacity-100 lg:translate-y-0 lg:flex lg:items-center lg:space-x-3 absolute lg:relative top-70 lg:top-0 left-0 lg:left-auto w-full lg:w-auto bg-white lg:bg-transparent pt-4 lg:pt-0 pb-6 lg:pb-0 px-5 lg:px-0 z-50 lg:z-auto overflow-hidden lg:overflow-visible transition-all duration-300 ease-in-out`}>
            <div className="flex flex-col lg:flex-row lg:items-center space-y-3 lg:space-y-0 lg:space-x-3">
              <Button title="Submit CV" className="bg-slate-light hover:bg-slate-light-hover text-black rounded-md" />
              <Button title="Find Your next Hire" className="bg-periwinkle-blue hover:bg-periwinkle-blue-hover text-white rounded-md" />
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden">
            <button
              onClick={toggleMenu}
              className="cursor-pointer inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
            >
              {isOpen ? (
                <RiCloseLine className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <RiMenuLine className="block h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;