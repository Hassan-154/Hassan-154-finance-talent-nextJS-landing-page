(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-icons_io5_index_mjs_39106f7b._.js",
  "static/chunks/node_modules_swiper_949ee926._.js",
  "static/chunks/node_modules_next_6323dc54._.js",
  "static/chunks/app_d557a042._.js",
  "static/chunks/node_modules_swiper_1e339522._.css"
],
    source: "dynamic"
});
