(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__501b62d3._.css",
  "static/chunks/node_modules_next_dist_016204b3._.js",
  "static/chunks/node_modules_react-icons_ri_index_mjs_0e2ec0a5._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/app_57bf9c30._.js"
],
    source: "dynamic"
});
