(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_350036a9._.js",
  "static/chunks/node_modules_react-icons_io5_index_mjs_39106f7b._.js",
  "static/chunks/node_modules_swiper_949ee926._.js",
  "static/chunks/node_modules_8d7ceabd._.js",
  "static/chunks/node_modules_8fb67bf9._.css"
],
    source: "dynamic"
});
